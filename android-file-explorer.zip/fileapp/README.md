# File Explorer — Native Android App

A native Android file manager with full access to your Download folder,
built with Kotlin + WebView.

## What it does
- Browse ANY folder on your device including Download, Documents, DCIM etc
- Rename files and folders (real native rename — no restrictions)
- Delete files
- Cut / Copy / Paste files between folders
- Create new folders and text files
- Sort by name, type, date, size
- Grid and list views

## How to build the APK

### Requirements
- [Android Studio](https://developer.android.com/studio) (free download, ~1GB)
- A PC or Mac

### Steps

1. **Download and install Android Studio** from https://developer.android.com/studio

2. **Open the project**
   - Open Android Studio
   - Click "Open" (or File → Open)
   - Select this `fileapp` folder

3. **Wait for Gradle sync** (~2-5 minutes on first open, downloads dependencies)

4. **Build the APK**
   - Menu: Build → Build Bundle(s) / APK(s) → Build APK(s)
   - Wait ~1-2 minutes
   - Click "locate" in the notification to find the APK

5. **Install on your Android device**
   - Enable "Install from unknown sources" on your phone:
     Settings → Security → Install unknown apps → allow your file manager
   - Copy the APK to your phone and tap it to install
   - OR connect via USB and click "Run" in Android Studio to install directly

### APK location after build
```
fileapp/app/build/outputs/apk/debug/app-debug.apk
```

## First launch
On first launch the app will ask for "All files access" permission.
Tap OK → Enable "Allow management of all files" in the settings screen.
This is required for the app to read and write your Download folder.

## Permissions used
- `MANAGE_EXTERNAL_STORAGE` — full file access (Android 11+)
- `READ/WRITE_EXTERNAL_STORAGE` — file access (Android 8-10)
