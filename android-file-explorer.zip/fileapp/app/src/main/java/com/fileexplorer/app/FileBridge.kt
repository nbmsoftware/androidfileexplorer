package com.fileexplorer.app

import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.webkit.JavascriptInterface
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class FileBridge(private val activity: MainActivity) {

    // ── Open file with associated app ─────────────────────
    @JavascriptInterface
    fun openFile(path: String): String {
        return try {
            val file = File(path)
            if (!file.exists()) return error("File not found: $path")
            if (!file.isFile) return error("Not a file")

            val uri: Uri = FileProvider.getUriForFile(
                activity,
                "${activity.packageName}.provider",
                file
            )

            val mime = getMimeType(file.name)

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            val chooser = Intent.createChooser(intent, "Open with")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            activity.startActivity(chooser)
            success("Opening ${file.name}")
        } catch (e: Exception) {
            error("Cannot open file: ${e.message}")
        }
    }

    private fun getMimeType(filename: String): String {
        return when (filename.substringAfterLast('.', "").lowercase()) {
            "jpg","jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "bmp" -> "image/bmp"
            "heic","heif" -> "image/heif"
            "svg" -> "image/svg+xml"
            "mp4" -> "video/mp4"
            "mkv" -> "video/x-matroska"
            "avi" -> "video/x-msvideo"
            "mov" -> "video/quicktime"
            "webm" -> "video/webm"
            "mp3" -> "audio/mpeg"
            "wav" -> "audio/wav"
            "flac" -> "audio/flac"
            "aac" -> "audio/aac"
            "ogg" -> "audio/ogg"
            "m4a" -> "audio/mp4"
            "pdf" -> "application/pdf"
            "doc" -> "application/msword"
            "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            "xls" -> "application/vnd.ms-excel"
            "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            "ppt" -> "application/vnd.ms-powerpoint"
            "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
            "txt","md","log","ini","cfg","env","sh","bat" -> "text/plain"
            "html","htm" -> "text/html"
            "css" -> "text/css"
            "js","ts" -> "text/javascript"
            "json" -> "application/json"
            "xml" -> "text/xml"
            "csv" -> "text/csv"
            "zip" -> "application/zip"
            "rar" -> "application/x-rar-compressed"
            "gz" -> "application/gzip"
            "tar" -> "application/x-tar"
            "7z" -> "application/x-7z-compressed"
            "apk" -> "application/vnd.android.package-archive"
            else -> "application/octet-stream"
        }
    }

    // ── Get well-known paths ──────────────────────────────
    @JavascriptInterface
    fun getDownloadsPath(): String =
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath

    @JavascriptInterface
    fun getExternalStoragePath(): String =
        Environment.getExternalStorageDirectory().absolutePath

    @JavascriptInterface
    fun getPublicDirs(): String {
        val dirs = listOf(
            mapOf("name" to "Download",  "path" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath),
            mapOf("name" to "Documents", "path" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).absolutePath),
            mapOf("name" to "Pictures",  "path" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).absolutePath),
            mapOf("name" to "DCIM",      "path" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).absolutePath),
            mapOf("name" to "Music",     "path" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC).absolutePath),
            mapOf("name" to "Movies",    "path" to Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).absolutePath),
        )
        val arr = JSONArray()
        dirs.forEach { d ->
            val o = JSONObject()
            o.put("name", d["name"])
            o.put("path", d["path"])
            o.put("exists", File(d["path"]!!).exists())
            arr.put(o)
        }
        return arr.toString()
    }

    // ── List directory ────────────────────────────────────
    @JavascriptInterface
    fun listDir(path: String): String {
        return try {
            val dir = File(path)
            if (!dir.exists()) return error("Path does not exist: $path")
            if (!dir.isDirectory) return error("Not a directory: $path")
            if (!dir.canRead()) return error("Permission denied reading: $path")

            val files = dir.listFiles() ?: return error("Cannot list directory")
            val arr = JSONArray()
            files.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
                .forEach { f ->
                    val o = JSONObject()
                    o.put("name", f.name)
                    o.put("path", f.absolutePath)
                    o.put("isDir", f.isDirectory)
                    o.put("size", if (f.isFile) f.length() else -1L)
                    o.put("modified", f.lastModified())
                    o.put("canWrite", f.canWrite())
                    arr.put(o)
                }
            val result = JSONObject()
            result.put("ok", true)
            result.put("entries", arr)
            result.toString()
        } catch (e: Exception) {
            error(e.message ?: "Unknown error")
        }
    }

    // ── Rename ────────────────────────────────────────────
    @JavascriptInterface
    fun rename(oldPath: String, newName: String): String {
        return try {
            val src = File(oldPath)
            if (!src.exists()) return error("File not found: $oldPath")
            val dest = File(src.parent, newName)
            if (dest.exists()) return error("\"$newName\" already exists")
            val ok = src.renameTo(dest)
            if (ok) success("Renamed successfully")
            else {
                if (src.isFile) {
                    copyFile(src, dest)
                    src.delete()
                    success("Renamed successfully")
                } else {
                    error("Could not rename folder")
                }
            }
        } catch (e: Exception) {
            error(e.message ?: "Rename failed")
        }
    }

    // ── Delete ────────────────────────────────────────────
    @JavascriptInterface
    fun delete(path: String): String {
        return try {
            val f = File(path)
            if (!f.exists()) return error("File not found")
            val ok = deleteRecursive(f)
            if (ok) success("Deleted") else error("Could not delete — file may be in use")
        } catch (e: Exception) {
            error(e.message ?: "Delete failed")
        }
    }

    private fun deleteRecursive(f: File): Boolean {
        if (f.isDirectory) f.listFiles()?.forEach { deleteRecursive(it) }
        return f.delete()
    }

    // ── Create folder ─────────────────────────────────────
    @JavascriptInterface
    fun createFolder(parentPath: String, name: String): String {
        return try {
            val dir = File(parentPath, name)
            if (dir.exists()) return error("\"$name\" already exists")
            val ok = dir.mkdirs()
            if (ok) success(dir.absolutePath) else error("Could not create folder")
        } catch (e: Exception) {
            error(e.message ?: "Create folder failed")
        }
    }

    // ── Create file ───────────────────────────────────────
    @JavascriptInterface
    fun createFile(parentPath: String, name: String): String {
        return try {
            val file = File(parentPath, name)
            if (file.exists()) return error("\"$name\" already exists")
            val ok = file.createNewFile()
            if (ok) success(file.absolutePath) else error("Could not create file")
        } catch (e: Exception) {
            error(e.message ?: "Create file failed")
        }
    }

    // ── Copy ──────────────────────────────────────────────
    @JavascriptInterface
    fun copy(srcPath: String, destDirPath: String, newName: String): String {
        return try {
            val src = File(srcPath)
            if (!src.exists()) return error("Source not found")
            val dest = File(File(destDirPath), newName.ifEmpty { src.name })
            if (src.isFile) copyFile(src, dest) else copyDir(src, dest)
            success("Copied")
        } catch (e: Exception) {
            error(e.message ?: "Copy failed")
        }
    }

    // ── Move ──────────────────────────────────────────────
    @JavascriptInterface
    fun move(srcPath: String, destDirPath: String, newName: String): String {
        return try {
            val src = File(srcPath)
            if (!src.exists()) return error("Source not found")
            val dest = File(File(destDirPath), newName.ifEmpty { src.name })
            if (src.renameTo(dest)) return success("Moved")
            if (src.isFile) copyFile(src, dest) else copyDir(src, dest)
            deleteRecursive(src)
            success("Moved")
        } catch (e: Exception) {
            error(e.message ?: "Move failed")
        }
    }

    // ── Helpers ───────────────────────────────────────────
    private fun copyFile(src: File, dest: File) {
        FileInputStream(src).use { i -> FileOutputStream(dest).use { o -> i.copyTo(o, 65536) } }
    }

    private fun copyDir(src: File, dest: File) {
        dest.mkdirs()
        src.listFiles()?.forEach { child ->
            if (child.isFile) copyFile(child, File(dest, child.name))
            else copyDir(child, File(dest, child.name))
        }
    }

    private fun success(msg: String): String {
        val o = JSONObject(); o.put("ok", true); o.put("msg", msg); return o.toString()
    }
    private fun error(msg: String): String {
        val o = JSONObject(); o.put("ok", false); o.put("error", msg); return o.toString()
    }
}
